
#include <glm/gtc/matrix_transform.hpp>

#include "PGUPV.h"

using namespace PGUPV;

using glm::vec3;
using glm::vec4;
using glm::mat3;
using glm::mat4;
using std::vector;

/*

Muestra una esfera texturada con una foto de la Tierra.

*/

class GameObject {
public:
	glm::vec3 position = glm::vec3(0, 0, 0);
	float rot_angle = 0;
	glm::vec3 rot_axis = glm::vec3(1, 0, 0);
	glm::vec3 scale = glm::vec3(1, 1, 1);
	std::shared_ptr<PGUPV::Model> model;
	std::vector<std::shared_ptr<GameObject>> children;
};

class MyRender : public Renderer {
public:
  MyRender(){};
  void setup(void);
  void render(void);
  void reshape(uint w, uint h);
  void update(uint ms);

private:
  std::shared_ptr<GLMatrices> mats;
  std::shared_ptr<Program> program;
  std::shared_ptr<Texture2D> innerTexture, outerTexture;
  std::shared_ptr<GameObject> outer_sph, inner_sph;
  float outer_speed = 1.0f;
  float inner_speed = 2.0f;
  float outer_scale = 1.0f;
  float inner_scale = 0.8f;
  void RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj);
};

void MyRender::setup() {
  glEnable(GL_DEPTH_TEST);
  glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

  /* Este shader necesita las coordenadas de los vértices y sus 
  coordenadas de textura */
  program = std::make_shared<Program>();
  program->addAttributeLocation(Mesh::VERTICES, "position");
  program->addAttributeLocation(Mesh::TEX_COORD0, "texCoord");

  mats = GLMatrices::build();
  program->connectUniformBlock(mats, UBO_GL_MATRICES_BINDING_INDEX);

  program->loadFiles("../p4b/textureReplace");
  program->compile();

  // Localización de los uniform (unidad de textura)
  GLint texUnitLoc = program->getUniformLocation("texUnit");
  // Comunicamos la unidad de textura al shader
  program->use();
  glUniform1i(texUnitLoc, 0);

  setCameraHandler(std::make_shared<OrbitCameraHandler>());

  // Creamos el orbe interior
  inner_sph = std::make_shared<GameObject>();
  inner_sph->model = std::make_shared<Sphere>();
  inner_sph->rot_axis = glm::vec3(0.0,0.5,0.5);
  inner_sph->scale = glm::vec3(inner_scale, inner_scale, inner_scale);

  // Creamos el orbe exterior
  outer_sph = std::make_shared<GameObject>();
  outer_sph->model = std::make_shared<Sphere>();
  outer_sph->rot_axis = glm::vec3(0.5, 0.5, 0.0);
  outer_sph->scale = glm::vec3(outer_scale, outer_scale, outer_scale);

  // Cargamos las texturas
  innerTexture = std::make_shared<Texture2D>();
  innerTexture->loadImage("../recursos/imagenes/lava.jpg");

  outerTexture = std::make_shared<Texture2D>();
  outerTexture->loadImage("../recursos/imagenes/energy2.jpg");
}

void MyRender::render() {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  mats->setMatrix(GLMatrices::VIEW_MATRIX, getCamera().getViewMatrix());

  innerTexture->bind(GL_TEXTURE0);
  RenderGameObject(mats, inner_sph);

  outerTexture->bind(GL_TEXTURE0);
  RenderGameObject(mats, outer_sph);

  CHECK_GL();
}

void MyRender::reshape(uint w, uint h) {
  glViewport(0, 0, w, h);
  mats->setMatrix(GLMatrices::PROJ_MATRIX, getCamera().getProjMatrix());
}

void MyRender::update(uint ms) {
  inner_sph->rot_angle += inner_speed * ms / 1000.0f;
  outer_sph->rot_angle += outer_speed * ms / 1000.0f;

  //if (angle > TWOPIf)
  //  angle -= TWOPIf;
}

void MyRender::RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj)
{
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, obj->position);
	mats->rotate(GLMatrices::MODEL_MATRIX, obj->rot_angle, obj->rot_axis);
	mats->scale(GLMatrices::MODEL_MATRIX, obj->scale);

	obj->model->render();

	for (size_t i = 0; i < obj->children.size(); i++)
	{
		RenderGameObject(mats, obj->children[i]);
	}

	mats->popMatrix(GLMatrices::MODEL_MATRIX);
}

int main(int argc, char *argv[]) {
  App &myApp = App::getInstance();
  myApp.initApp(argc, argv, PGUPV::DOUBLE_BUFFER | PGUPV::DEPTH_BUFFER |
                                PGUPV::MULTISAMPLE);
  myApp.getWindow().setRenderer(std::make_shared<MyRender>());
  return myApp.run();
}
