#include <PGUPV.h>
#include <GUI3.h>

using namespace PGUPV;

using glm::vec2;
using glm::vec3;
using glm::vec4;
using std::vector;

class MyRender : public Renderer {
public:
	MyRender() = default;
	void setup(void) override;
	void render(void) override;
	void reshape(uint w, uint h) override;
	void update(uint) override;
private:
	void buildModels();
	std::shared_ptr<GLMatrices> mats;
	Axes axes;
	std::vector<std::shared_ptr<Model>> models;
	
	void buildGUI();
	std::shared_ptr<IntSliderWidget> modelSelector;

	void LoadObjMesh(char* filename, int object, std::shared_ptr<Mesh> mesh);
	void ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z);
	void ReadVec2(std::string line, char separator, int startAt, double* x, double* y);
};

/**
Construye tus modelos y añádelos al vector models (quita los ejemplos siguientes). Recuerda
que no puedes usar directamente las clases predefinidas (tienes que construir los meshes y los
models a base de vértices, colores, etc.)
*/
void MyRender::buildModels()
{
	auto caja1 = std::make_shared<Box>(0.8f, 0.8f, 0.8f, glm::vec4(0.8f, 0.2f, 0.2f, 1.0f));
	models.push_back(caja1);
	auto caja2 = std::make_shared<Box>(0.9f, 0.9f, 0.9f, glm::vec4(0.2f, 0.8f, 0.2f, 1.0f));
	models.push_back(caja2);
	auto caja3 = std::make_shared<Box>(0.7f, 0.7f, 0.7f, glm::vec4(0.2f, 0.2f, 0.8f, 1.0f));
	models.push_back(caja3);
	
	auto palm1_mesh = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", 0, palm1_mesh);
	auto palm1_model = std::make_shared<Model>();
	palm1_model->addMesh(palm1_mesh);
	models.push_back(palm1_model);

	auto palm2_mesh = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", 1, palm2_mesh);
	auto palm2_model = std::make_shared<Model>();
	palm2_model->addMesh(palm2_mesh);
	models.push_back(palm2_model);
}


void MyRender::setup() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	// Habilitamos el z-buffer
	glEnable(GL_DEPTH_TEST);
	// Habilitamos el back face culling. ¡Cuidado! Si al dibujar un objeto hay 
	// caras que desaparecen o el modelo se ve raro, puede ser que estés 
	// definiendo los vértices del polígono del revés (en sentido horario)
	// Si ese es el caso, invierte el orden de los vértices.
	// Puedes activar/desactivar el back face culling en cualquier aplicación 
	// PGUPV pulsando las teclas CTRL+B
	glEnable(GL_CULL_FACE);

	mats = PGUPV::GLMatrices::build();

	// Activamos un shader que dibuja cada vértice con su atributo color
	ConstantIllumProgram::use();

	buildModels();

	// Establecemos una cámara que nos permite explorar el objeto desde cualquier
	// punto
	setCameraHandler(std::make_shared<OrbitCameraHandler>());

	// Construimos la interfaz de usuario
	buildGUI();
}

void MyRender::render() {
	// Borramos el buffer de color y el zbuffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Le pedimos a la cámara que nos de la matriz de la vista, que codifica la
	// posición y orientación actuales de la cámara.
	mats->setMatrix(GLMatrices::VIEW_MATRIX, getCamera().getViewMatrix());


	// Dibujamos los ejes
	axes.render();

	// Dibujamos los objetos
	if (!models.empty()) {
		models[modelSelector->get()]->render();
	}

	// Si la siguiente llamada falla, quiere decir que OpenGL se encuentra en
	// estado erróneo porque alguna de las operaciones que ha ejecutado
	// recientemente (después de la última llamada a CHECK_GL) ha tenido algún
	// problema. Revisa tu código.
	CHECK_GL();
}

void MyRender::reshape(uint w, uint h) {
	glViewport(0, 0, w, h);
	mats->setMatrix(GLMatrices::PROJ_MATRIX, getCamera().getProjMatrix());
}

// Este método se ejecuta una vez por frame, antes de llamada a render. Recibe el 
// número de milisegundos que han pasado desde la última vez que se llamó, y se suele
// usar para hacer animaciones o comprobar el estado de los dispositivos de entrada
void MyRender::update(uint) {
	// Si el usuario ha pulsado el espacio, ponemos la cámara en su posición inicial
	if (App::isKeyUp(PGUPV::KeyCode::Space)) {
		getCameraHandler()->resetView();
	}
}


/**
En éste método construimos los widgets que definen la interfaz de usuario. En esta
práctica no tienes que modificar esta función.
*/
void MyRender::buildGUI() {
	auto panel = addPanel("Modelos");
	modelSelector = std::make_shared<IntSliderWidget>("Model", 0, 0, static_cast<int>(models.size()-1));

	if (models.size() <= 1) {
		panel->addWidget(std::make_shared<Label>("Introduce algún modelo más en el vector models..."));
	}
	else {
		panel->addWidget(modelSelector);
	}
	App::getInstance().getWindow().showGUI();
}

void MyRender::LoadObjMesh(char* obj_path, int o_idx, std::shared_ptr<Mesh> mesh)
{
	std::ifstream in(obj_path, std::ios::in);
	if (!in)
	{
		std::cerr << "Cannot open " << obj_path << std::endl;
		exit(1);
	}

	std::vector<vec3> vertices;
	std::vector<GLushort> indices;
	std::vector<vec2> tex_coords;
	int o_count = -1;
	int v_offset = 1;
	int vt_offset = 1;
	int mat_idx = -1;

	std::string line;
	while (std::getline(in, line))
	{
		//check o for objects
		if (line.substr(0, 2) == "o ") o_count++;

		if (o_count == o_idx)
		{
			//check v for vertices
			if (line.substr(0, 2) == "v ") {
				double x, y, z;
				ReadVec3(line, ' ', 1, &x, &y, &z);
				glm::vec3 vert = glm::vec3(x, y, z);
				vertices.push_back(vert);
			}
			//check for faces
			else if (line.substr(0, 2) == "f ") {
				int a, b, c; //to store mesh index
				int i, j, k; //to store textCoord index
				const char* chh = line.c_str();
				sscanf(chh, "f %i/%i %i/%i %i/%i", &a, &i, &b, &j, &c, &k);
				a -= v_offset; b -= v_offset; c -= v_offset;
				//i -= vt_offset; j -= vt_offset; k -= vt_offset;
				indices.push_back(a); //tex_indices.push_back(i);
				indices.push_back(b); //tex_indices.push_back(j);
				indices.push_back(c); //tex_indices.push_back(k);
			}
			//check for texture coordinates
			else if (line.substr(0, 3) == "vt ") {
				double x, y;
				ReadVec2(line, ' ', 1, &x, &y);
				tex_coords.push_back(glm::vec2(x, y));
			}
		}
		else if (o_count < o_idx)
		{
			if (line.substr(0, 2) == "v ") v_offset++;
			else if (line.substr(0, 3) == "vt ") vt_offset++;
		}
	}

	std::cout << "Loaded object with vertices: " << vertices.size() << "\n";

	mesh->addVertices(vertices);
	mesh->addIndices(indices);

	mesh->addTexCoord(0, tex_coords);

	mesh->addDrawCommand(
		new PGUPV::DrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_SHORT, NULL));
}

void MyRender::ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		else if (count - startAt == 2) { *z = std::stod(s); }
		count++;
	}
}

void MyRender::ReadVec2(std::string line, char separator, int startAt, double* x, double* y)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		count++;
	}
}

int main(int argc, char* argv[]) {
	App& myApp = App::getInstance();
	myApp.initApp(argc, argv, PGUPV::DOUBLE_BUFFER | PGUPV::DEPTH_BUFFER |
		PGUPV::MULTISAMPLE);
	myApp.getWindow().setRenderer(std::make_shared<MyRender>());
	return myApp.run();
}