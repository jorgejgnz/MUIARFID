
#include "PGUPV.h"

#define _USE_MATH_DEFINES
#include <cmath>

using namespace PGUPV;

using glm::vec2;
using glm::vec3;
using glm::vec4;
using glm::mat3;
using glm::mat4;
using std::vector;

class GameObject {
public:
	glm::vec3 position = glm::vec3(0,0,0);
	float rot_angle = 0;
	glm::vec3 rot_axis = glm::vec3(1,0,0);
	glm::vec3 scale = glm::vec3(1,1,1);
	std::shared_ptr<PGUPV::Model> model;
	std::vector<std::shared_ptr<GameObject>> children;
};

class ObjMaterial {
public:
	char* name = new char[0]();
	glm::vec4 ambient = glm::vec4(0, 0, 1, 0);
	glm::vec4 diffuse = glm::vec4(0, 0, 1, 0);
	glm::vec4 specular = glm::vec4(0, 0, 1, 0);
	float opticalDensity = 0.0;
	float specularExponent = 0.0;
};

class MyRender : public Renderer {
public:
	MyRender() {};
	void setup(void) override;
	void render(void) override;
	void reshape(uint w, uint h) override;
	void update(uint ms) override;
private:
	std::shared_ptr<GLMatrices> mats;
	Axes axes;
	float defaultTreeScale = 0.25;
	int num_trees = 20;
	float streetLength = 10;
	float streetWidth = 3;
	float streetSpeed = 0.05;
	float streetHeight = -0.5;
	float opacity = 0.5;
	std::shared_ptr<Mesh> treeMesh1;
	std::shared_ptr<Mesh> treeMesh2;
	std::shared_ptr<PGUPV::Model> window_model;
	std::vector<std::shared_ptr<GameObject>> tree_pool;
	void LoadObjMesh(char* obj_path, char* mtl_path, int object, std::shared_ptr<Mesh> mesh);
	void ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z);
	void ReadVec2(std::string line, char separator, int startAt, double* x, double* y);
	void SetupPool(int size);
	void RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj);
	void QuatToAngleAxis(glm::quat q, std::shared_ptr<float> angle_rad, std::shared_ptr<glm::vec3> axis);
	void RandomizeTree(std::shared_ptr<GameObject> tree, std::shared_ptr<PGUPV::Mesh> mesh1, std::shared_ptr<PGUPV::Mesh> mesh2);
	void LoadWindowMesh(std::shared_ptr<PGUPV::Mesh> m, glm::vec4& color);
};

void MyRender::setup() {
	glClearColor(1.f, 1.f, 1.f, 1.0f);
	glEnable(GL_DEPTH_TEST);

	mats = GLMatrices::build();

	//setCameraHandler(std::make_shared<OrbitCameraHandler>(5.0f));
	mats->setMatrix(GLMatrices::VIEW_MATRIX, glm::lookAt(vec3(0.0f, 0.0f, 5.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f)));

	treeMesh1 = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", "../recursos/modelos/palms.mtl", 0, treeMesh1);

	treeMesh2 = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", "../recursos/modelos/palms.mtl", 1, treeMesh2);
	
	SetupPool(num_trees);

	std::cout << "Pool size: " << tree_pool.size() << "\n";

	float distBetweenTrees = (streetLength * 2) / ((float)num_trees / 2);

	int pairCount = 0;
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		tree_pool[i]->scale = glm::vec3(defaultTreeScale, defaultTreeScale, defaultTreeScale);

		if (i % 2 == 0)
		{
			tree_pool[i]->position.x = -(streetWidth / 2);
			pairCount++;
		}
		else
		{
			tree_pool[i]->position.x = (streetWidth / 2);
		}

		tree_pool[i]->position.z = -pairCount * distBetweenTrees;
		tree_pool[i]->position.y = streetHeight;

		RandomizeTree(tree_pool[i], treeMesh1, treeMesh2);
	}

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

/*
Tienes que completar esta función para dibujar la escena.
*/
void MyRender::render() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//mats->setMatrix(GLMatrices::VIEW_MATRIX, getCamera().getViewMatrix());

	// Instalar el shader para dibujar los ejes, las normales y la luz
	ConstantIllumProgram::use();

	// Aplicamos la rotación a los ejes
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, streetHeight, -streetLength);
	//mats->rotate(GLMatrices::MODEL_MATRIX, rotationAngle, glm::vec3{ 0.0f, 1.0f, 0.0f });
	mats->scale(GLMatrices::MODEL_MATRIX,streetWidth/2,1,2*streetLength);
	// Dibujamos los ejes de coordenadas
	axes.render();
	mats->popMatrix(GLMatrices::MODEL_MATRIX);

	glEnable(GL_STENCIL_TEST);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glStencilFunc(GL_EQUAL, 0x1, 0x1);
	/* Sólo se procesarán los píxeles cuyo valor de stencil sea 1 */	
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		RenderGameObject(mats, tree_pool[i]);
	}

	glEnable(GL_BLEND);
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, 0, 4.0);
	window_model->render();
	mats->popMatrix(GLMatrices::MODEL_MATRIX);
	glDisable(GL_BLEND);

	glStencilFunc(GL_NOTEQUAL, 0x1, 0x1);
	/* Sólo se procesarán los píxeles cuyo valor de stencil sea distinto de 1 */

	glDisable(GL_STENCIL_TEST);
	
	CHECK_GL();
}

void MyRender::reshape(uint w, uint h) {
	glViewport(0, 0, w, h);
	//mats->setMatrix(GLMatrices::PROJ_MATRIX, getCamera().getProjMatrix());
	float ar = (float)w / h;
	mats->setMatrix(GLMatrices::PROJ_MATRIX, glm::perspective(70.0f, ar, 0.001f, 1000.0f));

	glClear(GL_STENCIL_BUFFER_BIT);
	glStencilFunc(GL_ALWAYS, 0x1, 0xFF);
	glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);

	glDisable(GL_DEPTH_TEST);

	glColorMask(false, false, false, false);
	
	glEnable(GL_STENCIL_TEST);
	window_model = std::make_shared<PGUPV::Model>();
	std::shared_ptr<PGUPV::Mesh> window_mesh = std::make_shared<PGUPV::Mesh>();
	glm::vec4 c = glm::vec4(0.0,0.0,1.0,opacity);
	LoadWindowMesh(window_mesh, c);
	window_model->addMesh(window_mesh);
	window_model->render();
	glDisable(GL_STENCIL_TEST);

	glColorMask(true, true, true, true);

	glEnable(GL_DEPTH_TEST);
}

// Radianes por segundo a los que giran los ejes
#define SPINSPEED glm::radians(90.0f)

void MyRender::update(uint ms) {
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		if (tree_pool[i]->position.z > streetLength)
		{
			tree_pool[i]->position.z = -streetLength;
			RandomizeTree(tree_pool[i], treeMesh1, treeMesh2);
		}
		else tree_pool[i]->position.z += streetSpeed;
	}
}

int main(int argc, char* argv[]) {
	App& myApp = App::getInstance();
	myApp.setInitWindowSize(800, 600);
	myApp.initApp(argc, argv, PGUPV::DOUBLE_BUFFER | PGUPV::DEPTH_BUFFER | PGUPV::MULTISAMPLE | PGUPV::STENCIL_BUFFER);
	myApp.getWindow().setRenderer(std::make_shared<MyRender>());
	return myApp.run();
}

void MyRender::LoadObjMesh(char* obj_path, char* mtl_path, int o_idx, std::shared_ptr<Mesh> mesh)
{
	std::shared_ptr<ObjMaterial> mat;
	std::vector<std::shared_ptr<ObjMaterial>> materials;
	std::ifstream in(mtl_path, std::ios::in);
	if (!in)
	{
		std::cerr << "Cannot open " << mtl_path << std::endl;
		exit(1);
	}
	std::string line;
	while (std::getline(in, line))
	{
		if (line.substr(0, 7) == "newmtl ")
		{
			mat = std::make_shared<ObjMaterial>();
			materials.push_back(mat);

			const char* chh = line.c_str();
			sscanf(chh, "newmtl %s", mat->name);
		}
		else if (line.substr(0, 3) == "Ka ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->ambient = glm::vec4(r, g, b, 1.0);
		}
		else if (line.substr(0, 3) == "Kd ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->diffuse = glm::vec4(r, g, b, 1.0);
		}
		else if (line.substr(0, 3) == "Ks ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->specular = glm::vec4(r, g, b, 1.0);;
		}
		else if (line.substr(0, 3) == "Ns ")
		{
			const char* chh = line.c_str();
			float ns;
			sscanf(chh, "Ns %f", &ns);
			mat->specularExponent = ns;
		}
		else if (line.substr(0, 3) == "Ni ")
		{
			const char* chh = line.c_str();
			float ni;
			sscanf(chh, "Ni %f", &ni);
			mat->opticalDensity = ni;
		}
	}

	std::vector<vec3> vertices;
	std::vector<GLushort> indices;
	std::vector<vec2> tex_coords;
	std::vector<vec4> vertex_colors;
	int o_count = -1;
	int v_offset = 1;
	int vt_offset = 1;
	int mat_idx = -1;
	in = std::ifstream(obj_path, std::ios::in);
	if (!in)
	{
		std::cerr << "Cannot open " << obj_path << std::endl;
		exit(1);
	}
	while (std::getline(in, line))
	{
		//check o for objects
		if (line.substr(0, 2) == "o ") o_count++;

		if (o_count == o_idx)
		{
			//check v for vertices
			if (line.substr(0, 2) == "v ") {
				double x, y, z;
				ReadVec3(line, ' ', 1, &x, &y, &z);
				glm::vec3 vert = glm::vec3(x, y, z);
				vertices.push_back(vert);
				// initialice color vector
				glm::vec4 c;
				vertex_colors.push_back(c);
			}
			//check for faces
			else if (line.substr(0, 2) == "f ") {
				int a, b, c; //to store mesh index
				int i, j, k; //to store textCoord index
				const char* chh = line.c_str();
				sscanf(chh, "f %i/%i %i/%i %i/%i", &a, &i, &b, &j, &c, &k);
				a -= v_offset; b -= v_offset; c -= v_offset;
				//i -= vt_offset; j -= vt_offset; k -= vt_offset;
				indices.push_back(a); //tex_indices.push_back(i);
				indices.push_back(b); //tex_indices.push_back(j);
				indices.push_back(c); //tex_indices.push_back(k);
				// apply material (only color for now)
				vertex_colors[a] = materials[mat_idx]->diffuse;
				vertex_colors[b] = materials[mat_idx]->diffuse;
				vertex_colors[c] = materials[mat_idx]->diffuse;
			}
			//check for materials
			else if (line.substr(0, 7) == "usemtl ") {
				// search and update material idx to be used in following parsed lines
				const char* chh = line.c_str();
				char* mat_name = new char[0]();
				sscanf(chh, "usemtl %s", mat_name);
				for (size_t i = 0; i < materials.size(); i++)
				{
					int diff = strcmp(materials[i]->name, mat_name);
					if (diff == 0)
					{
						mat_idx = i;
						break;
					}
				}
			}
			//check for texture coordinates
			else if (line.substr(0, 3) == "vt ") {
				double x, y;
				ReadVec2(line, ' ', 1, &x, &y);
				tex_coords.push_back(glm::vec2(x, y));
			}
		}
		else if (o_count < o_idx)
		{
			if (line.substr(0, 2) == "v ") v_offset++;
			else if (line.substr(0, 3) == "vt ") vt_offset++;
		}
	}

	std::cout << "Loaded object with vertices: " << vertices.size() << "\n";

	mesh->addVertices(vertices);
	mesh->addIndices(indices);
	mesh->addColors(vertex_colors);

	mesh->addTexCoord(0, tex_coords);

	mesh->addDrawCommand(
		new PGUPV::DrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_SHORT, NULL));
}

void MyRender::ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		else if (count - startAt == 2) { *z = std::stod(s); }
		count++;
	}
}

void MyRender::ReadVec2(std::string line, char separator, int startAt, double* x, double* y)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		count++;
	}
}

void MyRender::SetupPool(int size)
{
	for (size_t i = 0; i < size; i++)
	{
		auto obj = std::make_shared<GameObject>();
		obj->model = std::make_shared<Model>();
		tree_pool.push_back(obj);
	}
}

void MyRender::RandomizeTree(std::shared_ptr<GameObject> tree, std::shared_ptr<PGUPV::Mesh> mesh1, std::shared_ptr<PGUPV::Mesh> mesh2)
{
	// Scale (0.8 to 1.2)
	float r = float(rand()) / (RAND_MAX);
	r = (0.8 + r * 0.4) * defaultTreeScale;
	tree->scale = glm::vec3(r,r,r);

	// Rotation
	r = float(rand()) / (RAND_MAX);
	tree->rot_angle = r * 2 * M_PI;
	tree->rot_axis = glm::vec3(0,1,0);

	// Mesh
	tree->model->clearMeshes();
	std::shared_ptr<Mesh> mesh;
	if (float(rand()) / (RAND_MAX) > 0.5) mesh = mesh1;
	else mesh = mesh2;
	tree->model->addMesh(mesh);
}

void MyRender::RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj)
{
	// aplicar transformaciones
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, obj->position);
	mats->rotate(GLMatrices::MODEL_MATRIX, obj->rot_angle, obj->rot_axis);
	mats->scale(GLMatrices::MODEL_MATRIX, obj->scale);

	obj->model->render();

	for (size_t i = 0; i < obj->children.size(); i++)
	{
		RenderGameObject(mats, obj->children[i]);
	}

	mats->popMatrix(GLMatrices::MODEL_MATRIX);
}

void MyRender::QuatToAngleAxis(glm::quat q, std::shared_ptr<float> angle_rad, std::shared_ptr<glm::vec3> axis)
{
	*angle_rad = acos(q.w) * 2;
	float angle_deg = *angle_rad * 180 / M_PI;
	float x = q.x / sin(*angle_rad / 2);
	float y = q.y / sin(*angle_rad / 2);
	float z = q.z / sin(*angle_rad / 2);

	*axis = glm::vec3(x, y, z);
}

void MyRender::LoadWindowMesh(std::shared_ptr<PGUPV::Mesh> m, glm::vec4& color)
{
	float x_offset = 0.0;
	float y_offset = 0.0;

	// x_values.size() debe ser igual a y_values.size()

	std::vector<std::vector<float>> x_values(3);
	x_values[0] = { -0.5,0.5 };
	x_values[1] = { -0.8,0.8 };
	x_values[2] = { -0.9,0.9 };

	std::vector<float> y_values = { 0.5, 0.0, -0.5 };

	int nVertX = x_values[0].size();
	int nVertY = y_values.size();

	uint nTotalVertices = nVertX * nVertY;

	std::vector<vec3> vs(nTotalVertices);
	std::vector<vec3> ns(nTotalVertices);
	std::vector<vec2> ts(nTotalVertices);

	uint nStrips = nVertY - 1;
	uint nIndicesPerStrip = 2 * nVertX + 1; // +1 : primitive restart
	uint nTotalIndices = nStrips * nIndicesPerStrip;

	std::vector<uint> is(nTotalIndices);

	uint iv = 0;
	for (uint j = 0; j < nVertY; j++) {
		for (uint i = 0; i < nVertX; i++) {
			vs[iv] = vec3(x_offset + x_values[j][i], y_offset + y_values[j], 0.0f);
			ns[iv] = vec3(0.0, 0.0, 1.0);
			ts[iv] = vec2((float)i / (nVertX - 1), (float)j / (nVertY - 1));
			iv++;
		}
	}

	iv = 0;
	for (uint j = 0; j < nStrips; j++) {
		uint upperIndex = (j + 1) * nVertX;
		uint lowerIndex = j * nVertX;
		for (uint i = 0; i < nVertX; i++) {
			is[iv++] = upperIndex++;
			is[iv++] = lowerIndex++;
		}
		is[iv++] = (uint)-1;
	}

	m->addVertices(vs);
	m->setColor(color);
	m->addNormals(ns);
	m->addTexCoord(0, ts);
	m->addIndices(is);

	auto dc = new PGUPV::DrawElements(GL_TRIANGLE_STRIP, nTotalIndices, GL_UNSIGNED_INT, (void*)0);
	dc->setPrimitiveRestart();
	dc->setRestartIndex((uint)-1);

	m->addDrawCommand(dc);
}

