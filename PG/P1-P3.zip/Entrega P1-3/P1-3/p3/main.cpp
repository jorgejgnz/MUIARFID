
#include "PGUPV.h"

#define _USE_MATH_DEFINES
#include <cmath>

using namespace PGUPV;

using glm::vec2;
using glm::vec3;
using glm::vec4;
using glm::mat3;
using glm::mat4;
using std::vector;

class GameObject {
public:
	glm::vec3 position = glm::vec3(0,0,0);
	float rot_angle = 0;
	glm::vec3 rot_axis = glm::vec3(1,0,0);
	glm::vec3 scale = glm::vec3(1,1,1);
	std::shared_ptr<PGUPV::Model> model;
	std::vector<std::shared_ptr<GameObject>> children;
};

class ObjMaterial {
public:
	char* name = new char[0]();
	glm::vec4 ambient = glm::vec4(0, 0, 1, 0);
	glm::vec4 diffuse = glm::vec4(0, 0, 1, 0);
	glm::vec4 specular = glm::vec4(0, 0, 1, 0);
	float opticalDensity = 0.0;
	float specularExponent = 0.0;
};

class MyRender : public Renderer {
public:
	MyRender() {};
	void setup(void) override;
	void render(void) override;
	void reshape(uint w, uint h) override;
	void update(uint ms) override;
private:
	std::shared_ptr<GLMatrices> mats;
	Axes axes;
	float defaultTreeScale = 0.25;
	int num_trees = 20;
	int num_roads = 6;
	float width = 0.0f;
	float height = 0.0f;
	float streetLength = 10;
	float streetWidth = 3;
	float streetSpeed = 0.05;
	float streetHeight = -0.5;
	float opacity = 0.5;
	std::shared_ptr<Mesh> treeMesh1, treeMesh2, roadMesh, logoMesh;
	std::shared_ptr<PGUPV::Model> window_model, interior_model;
	std::shared_ptr<GameObject> logo;
	std::vector<std::shared_ptr<GameObject>> tree_pool, road_pool;
	std::shared_ptr<Texture2D> interior_texture, road_texture, logo_texture;
	void LoadObjMesh(char* obj_path, char* mtl_path, int object, std::shared_ptr<Mesh> mesh);
	void LoadWindowMesh(std::shared_ptr<PGUPV::Mesh> m, glm::vec4& color);
	void LoadRoadMesh(std::shared_ptr<Mesh> m, glm::vec4 color, float width, float depth);
	void LoadCube(std::shared_ptr<Mesh> m);
	void ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z);
	void ReadVec2(std::string line, char separator, int startAt, double* x, double* y);
	void SetupPool(int size, std::vector<std::shared_ptr<GameObject>> *pool);
	void RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj);
	void QuatToAngleAxis(glm::quat q, std::shared_ptr<float> angle_rad, std::shared_ptr<glm::vec3> axis);
	void RandomizeTree(std::shared_ptr<GameObject> tree, std::shared_ptr<PGUPV::Mesh> mesh1, std::shared_ptr<PGUPV::Mesh> mesh2);
};

void MyRender::setup() {
	glClearColor(1.f, 1.f, 1.f, 1.0f);
	glEnable(GL_DEPTH_TEST);

	mats = GLMatrices::build();

	//setCameraHandler(std::make_shared<OrbitCameraHandler>(5.0f));
	mats->setMatrix(GLMatrices::VIEW_MATRIX, glm::lookAt(vec3(0.0f, 0.0f, 5.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f)));

	treeMesh1 = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", "../recursos/modelos/palms.mtl", 0, treeMesh1);

	treeMesh2 = std::make_shared<Mesh>();
	LoadObjMesh("../recursos/modelos/palms.obj", "../recursos/modelos/palms.mtl", 1, treeMesh2);

	logoMesh = std::make_shared<Mesh>();
	LoadCube(logoMesh);

	roadMesh = std::make_shared<Mesh>();
	LoadRoadMesh(roadMesh, glm::vec4(0.5,0.5,0.5,1), streetWidth - 0.5f, 3.5f);

	interior_texture = std::make_shared<Texture2D>();
	interior_texture->loadImage("../recursos/imagenes/interior.png");

	road_texture = std::make_shared<Texture2D>();
	road_texture->loadImage("../recursos/imagenes/asfalto.png");
	road_texture->generateMipmap();

	logo_texture = std::make_shared<Texture2D>();
	logo_texture->loadImage("../recursos/imagenes/logo.png");

	// Trees
	SetupPool(num_trees, &tree_pool);
	int pairCount = 0;
	float distBetweenTrees = (streetLength * 2) / ((float)num_trees / 2);
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		tree_pool[i]->scale = glm::vec3(defaultTreeScale, defaultTreeScale, defaultTreeScale);

		if (i % 2 == 0)
		{
			tree_pool[i]->position.x = -(streetWidth / 2);
			pairCount++;
		}
		else
		{
			tree_pool[i]->position.x = (streetWidth / 2);
		}

		tree_pool[i]->position.z = -pairCount * distBetweenTrees;
		tree_pool[i]->position.y = streetHeight;

		RandomizeTree(tree_pool[i], treeMesh1, treeMesh2);
	}

	// Roads
	SetupPool(num_roads, &road_pool);
	float distBetweenRoads = (streetLength * 2) / ((float)num_roads);
	for (size_t i = 0; i < road_pool.size(); i++)
	{
		road_pool[i]->model->addMesh(roadMesh);
		road_pool[i]->position.z = -1.0f * (float)i * distBetweenRoads;
		road_pool[i]->position.y = streetHeight;

		//std::dynamic_pointer_cast<Material>(road_pool[i]->model->getMesh(0).getMaterial())->setDiffuseTexture(road_texture);
	}

	//Logo
	logo = std::make_shared<GameObject>();
	logo->model = std::make_shared<Model>();
	logo->model->addMesh(logoMesh);
	logo->scale = glm::vec3(0.5, 0.5, 0.5);
	logo->position = glm::vec3(-2.5,-2,-1);
	logo->rot_axis = glm::vec3(0,1,0);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

/*
Tienes que completar esta función para dibujar la escena.
*/
void MyRender::render() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//mats->setMatrix(GLMatrices::VIEW_MATRIX, getCamera().getViewMatrix());

	// Instalar el shader para dibujar los ejes, las normales y la luz
	ConstantIllumProgram::use();

	// Aplicamos la rotación a los ejes
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, streetHeight, -streetLength);
	//mats->rotate(GLMatrices::MODEL_MATRIX, rotationAngle, glm::vec3{ 0.0f, 1.0f, 0.0f });
	mats->scale(GLMatrices::MODEL_MATRIX,streetWidth/2,1,2*streetLength);
	// Dibujamos los ejes de coordenadas
	axes.render();
	mats->popMatrix(GLMatrices::MODEL_MATRIX);

	glEnable(GL_STENCIL_TEST);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glStencilFunc(GL_EQUAL, 0x1, 0x1);
	/* Sólo se procesarán los píxeles cuyo valor de stencil sea 1 */	
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		RenderGameObject(mats, tree_pool[i]);
	}

	TextureReplaceProgram::use();

	for (size_t i = 0; i < road_pool.size(); i++)
	{
		road_texture->bind(GL_TEXTURE0);
		RenderGameObject(mats, road_pool[i]);
	}

	ConstantIllumProgram::use();

	glEnable(GL_BLEND);
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, 0, 4.9);
	window_model->render();
	mats->popMatrix(GLMatrices::MODEL_MATRIX);
	glDisable(GL_BLEND);

	glStencilFunc(GL_NOTEQUAL, 0x1, 0x1);
	/* Sólo se procesarán los píxeles cuyo valor de stencil sea distinto de 1 */
	Rect rectangulo(1.28f, 0.72f);
	rectangulo.getMesh(0).setColor(glm::vec4(0,0,0,1));
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, -0.1, 4.5);

	interior_texture->bind(GL_TEXTURE0);
	TextureReplaceProgram::use();
	rectangulo.render();

	mats->popMatrix(GLMatrices::MODEL_MATRIX);

	glDisable(GL_STENCIL_TEST);

	glClear(GL_DEPTH_BUFFER_BIT);
	TextureReplaceProgram::use();
	logo_texture->bind(GL_TEXTURE0);
	RenderGameObject(mats, logo);
	ConstantIllumProgram::use();
	
	CHECK_GL();
}

void MyRender::reshape(uint w, uint h) {
	glViewport(0, 0, w, h);
	//mats->setMatrix(GLMatrices::PROJ_MATRIX, getCamera().getProjMatrix());
	float ar = (float)w / h;
	mats->setMatrix(GLMatrices::PROJ_MATRIX, glm::perspective(70.0f, ar, 0.001f, 1000.0f));

	glClear(GL_STENCIL_BUFFER_BIT);
	glStencilFunc(GL_ALWAYS, 0x1, 0xFF);
	glStencilOp(GL_REPLACE, GL_REPLACE, GL_REPLACE);

	glDisable(GL_DEPTH_TEST);

	glColorMask(false, false, false, false);
	
	glEnable(GL_STENCIL_TEST);
	window_model = std::make_shared<PGUPV::Model>();
	std::shared_ptr<PGUPV::Mesh> window_mesh = std::make_shared<PGUPV::Mesh>();
	glm::vec4 c = glm::vec4(0.0,0.0,1.0,opacity);
	LoadWindowMesh(window_mesh, c);
	window_model->addMesh(window_mesh);
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, 0, 0, 2.5);
	window_model->render();
	mats->popMatrix(GLMatrices::MODEL_MATRIX);
	glDisable(GL_STENCIL_TEST);

	glColorMask(true, true, true, true);

	glEnable(GL_DEPTH_TEST);

	height = h;
	width = w;
}

// Radianes por segundo a los que giran los ejes
#define SPINSPEED glm::radians(90.0f)

void MyRender::update(uint ms) {
	// Move trees
	for (size_t i = 0; i < tree_pool.size(); i++)
	{
		if (tree_pool[i]->position.z > streetLength)
		{
			tree_pool[i]->position.z = -streetLength;
			RandomizeTree(tree_pool[i], treeMesh1, treeMesh2);
		}
		else tree_pool[i]->position.z += streetSpeed;
	}
	// Move roads
	for (size_t i = 0; i < road_pool.size(); i++)
	{
		if (road_pool[i]->position.z > streetLength)
		{
			road_pool[i]->position.z = -streetLength;
		}
		else road_pool[i]->position.z += streetSpeed;
	}
	//Move logo
	logo->rot_angle += 0.01;

	reshape(width, height);
}

int main(int argc, char* argv[]) {
	App& myApp = App::getInstance();
	myApp.setInitWindowSize(800, 600);
	myApp.initApp(argc, argv, PGUPV::DOUBLE_BUFFER | PGUPV::DEPTH_BUFFER | PGUPV::MULTISAMPLE | PGUPV::STENCIL_BUFFER);
	myApp.getWindow().setRenderer(std::make_shared<MyRender>());
	return myApp.run();
}

void MyRender::LoadObjMesh(char* obj_path, char* mtl_path, int o_idx, std::shared_ptr<Mesh> mesh)
{
	std::shared_ptr<ObjMaterial> mat;
	std::vector<std::shared_ptr<ObjMaterial>> materials;
	std::ifstream in(mtl_path, std::ios::in);
	if (!in)
	{
		std::cerr << "Cannot open " << mtl_path << std::endl;
		exit(1);
	}
	std::string line;
	while (std::getline(in, line))
	{
		if (line.substr(0, 7) == "newmtl ")
		{
			mat = std::make_shared<ObjMaterial>();
			materials.push_back(mat);

			const char* chh = line.c_str();
			sscanf(chh, "newmtl %s", mat->name);
		}
		else if (line.substr(0, 3) == "Ka ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->ambient = glm::vec4(r, g, b, 1.0);
		}
		else if (line.substr(0, 3) == "Kd ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->diffuse = glm::vec4(r, g, b, 1.0);
		}
		else if (line.substr(0, 3) == "Ks ")
		{
			double r, g, b;
			ReadVec3(line, ' ', 1, &r, &g, &b);
			mat->specular = glm::vec4(r, g, b, 1.0);;
		}
		else if (line.substr(0, 3) == "Ns ")
		{
			const char* chh = line.c_str();
			float ns;
			sscanf(chh, "Ns %f", &ns);
			mat->specularExponent = ns;
		}
		else if (line.substr(0, 3) == "Ni ")
		{
			const char* chh = line.c_str();
			float ni;
			sscanf(chh, "Ni %f", &ni);
			mat->opticalDensity = ni;
		}
	}

	std::vector<vec3> vertices;
	std::vector<GLushort> indices;
	std::vector<vec2> tex_coords;
	std::vector<vec4> vertex_colors;
	int o_count = -1;
	int v_offset = 1;
	int vt_offset = 1;
	int mat_idx = -1;
	in = std::ifstream(obj_path, std::ios::in);
	if (!in)
	{
		std::cerr << "Cannot open " << obj_path << std::endl;
		exit(1);
	}
	while (std::getline(in, line))
	{
		//check o for objects
		if (line.substr(0, 2) == "o ") o_count++;

		if (o_count == o_idx)
		{
			//check v for vertices
			if (line.substr(0, 2) == "v ") {
				double x, y, z;
				ReadVec3(line, ' ', 1, &x, &y, &z);
				glm::vec3 vert = glm::vec3(x, y, z);
				vertices.push_back(vert);
				// initialice color vector
				glm::vec4 c;
				vertex_colors.push_back(c);
			}
			//check for faces
			else if (line.substr(0, 2) == "f ") {
				int a, b, c; //to store mesh index
				int i, j, k; //to store textCoord index
				const char* chh = line.c_str();
				sscanf(chh, "f %i/%i %i/%i %i/%i", &a, &i, &b, &j, &c, &k);
				a -= v_offset; b -= v_offset; c -= v_offset;
				//i -= vt_offset; j -= vt_offset; k -= vt_offset;
				indices.push_back(a); //tex_indices.push_back(i);
				indices.push_back(b); //tex_indices.push_back(j);
				indices.push_back(c); //tex_indices.push_back(k);
				// apply material (only color for now)
				vertex_colors[a] = materials[mat_idx]->diffuse;
				vertex_colors[b] = materials[mat_idx]->diffuse;
				vertex_colors[c] = materials[mat_idx]->diffuse;
			}
			//check for materials
			else if (line.substr(0, 7) == "usemtl ") {
				// search and update material idx to be used in following parsed lines
				const char* chh = line.c_str();
				char* mat_name = new char[0]();
				sscanf(chh, "usemtl %s", mat_name);
				for (size_t i = 0; i < materials.size(); i++)
				{
					int diff = strcmp(materials[i]->name, mat_name);
					if (diff == 0)
					{
						mat_idx = i;
						break;
					}
				}
			}
			//check for texture coordinates
			else if (line.substr(0, 3) == "vt ") {
				double x, y;
				ReadVec2(line, ' ', 1, &x, &y);
				tex_coords.push_back(glm::vec2(x, y));
			}
		}
		else if (o_count < o_idx)
		{
			if (line.substr(0, 2) == "v ") v_offset++;
			else if (line.substr(0, 3) == "vt ") vt_offset++;
		}
	}

	std::cout << "Loaded object with vertices: " << vertices.size() << "\n";

	mesh->addVertices(vertices);
	mesh->addIndices(indices);
	mesh->addColors(vertex_colors);

	mesh->addTexCoord(0, tex_coords);

	mesh->addDrawCommand(
		new PGUPV::DrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_SHORT, NULL));
}

void MyRender::ReadVec3(std::string line, char separator, int startAt, double* x, double* y, double* z)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		else if (count - startAt == 2) { *z = std::stod(s); }
		count++;
	}
}

void MyRender::ReadVec2(std::string line, char separator, int startAt, double* x, double* y)
{
	std::istringstream iss(line);
	std::string s;
	int count = 0;
	while (std::getline(iss, s, separator)) {
		if (count - startAt == 0) { *x = std::stod(s); }
		else if (count - startAt == 1) { *y = std::stod(s); }
		count++;
	}
}

void MyRender::SetupPool(int size, std::vector<std::shared_ptr<GameObject>> *pool)
{
	for (size_t i = 0; i < size; i++)
	{
		auto obj = std::make_shared<GameObject>();
		obj->model = std::make_shared<Model>();
		pool->push_back(obj);
	}
}

void MyRender::RandomizeTree(std::shared_ptr<GameObject> tree, std::shared_ptr<PGUPV::Mesh> mesh1, std::shared_ptr<PGUPV::Mesh> mesh2)
{
	// Scale (0.8 to 1.2)
	float r = float(rand()) / (RAND_MAX);
	r = (0.8 + r * 0.4) * defaultTreeScale;
	tree->scale = glm::vec3(r,r,r);

	// Rotation
	r = float(rand()) / (RAND_MAX);
	tree->rot_angle = r * 2 * M_PI;
	tree->rot_axis = glm::vec3(0,1,0);

	// Mesh
	tree->model->clearMeshes();
	std::shared_ptr<Mesh> mesh;
	if (float(rand()) / (RAND_MAX) > 0.5) mesh = mesh1;
	else mesh = mesh2;
	tree->model->addMesh(mesh);
}

void MyRender::RenderGameObject(std::shared_ptr<PGUPV::GLMatrices> mats, std::shared_ptr<GameObject> obj)
{
	// aplicar transformaciones
	mats->pushMatrix(GLMatrices::MODEL_MATRIX);
	mats->translate(GLMatrices::MODEL_MATRIX, obj->position);
	mats->rotate(GLMatrices::MODEL_MATRIX, obj->rot_angle, obj->rot_axis);
	mats->scale(GLMatrices::MODEL_MATRIX, obj->scale);

	obj->model->render();

	for (size_t i = 0; i < obj->children.size(); i++)
	{
		RenderGameObject(mats, obj->children[i]);
	}

	mats->popMatrix(GLMatrices::MODEL_MATRIX);
}

void MyRender::QuatToAngleAxis(glm::quat q, std::shared_ptr<float> angle_rad, std::shared_ptr<glm::vec3> axis)
{
	*angle_rad = acos(q.w) * 2;
	float angle_deg = *angle_rad * 180 / M_PI;
	float x = q.x / sin(*angle_rad / 2);
	float y = q.y / sin(*angle_rad / 2);
	float z = q.z / sin(*angle_rad / 2);

	*axis = glm::vec3(x, y, z);
}

void MyRender::LoadWindowMesh(std::shared_ptr<PGUPV::Mesh> m, glm::vec4& color)
{
	float x_scale = 3.0;
	float y_scale = 1.5;
	float x_offset = -0.8;
	float y_offset = 0.4;

	std::vector<glm::vec3> vertices = {
		glm::vec3(-0.5,0.5,0),	// 0
		glm::vec3(-0.4,0.5,0),	// 1
		glm::vec3(-0.3,0.5,0),	// 2
		glm::vec3(1.4,0.5,0),	// 3
		glm::vec3(-0.5,-1.0,0),	// 4
		glm::vec3(-0.2,-0.6,0),	// 5
		glm::vec3(-0.1,-0.5,0),	// 6
		glm::vec3(1.3,-0.5,0)	// 7
	};

	// apply scale and offsets
	for (size_t i = 0; i < vertices.size(); i++)
	{
		vertices[i].x = x_offset + (vertices[i].x * x_scale);
		vertices[i].y = y_offset + (vertices[i].y * y_scale);
	}

	std::vector<GLushort> indices = {
		1,0,5,
		5,0,4,
		3,2,6,
		3,6,7
	};

	std::vector<glm::vec3> normals = {
		glm::vec3(0,0,1),	// 0
		glm::vec3(0,0,1),	// 1
		glm::vec3(0,0,1),	// 2
		glm::vec3(0,0,1),	// 3
		glm::vec3(0,0,1),	// 4
		glm::vec3(0,0,1),	// 5
		glm::vec3(0,0,1),	// 6
		glm::vec3(0,0,1)	// 7
	};

	m->addVertices(vertices);
	m->setColor(color);
	m->addIndices(indices);
	m->addNormals(normals);

	auto dc = new PGUPV::DrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_SHORT, (void*)0);
	dc->setPrimitiveRestart();
	dc->setRestartIndex((uint)-1);

	m->addDrawCommand(dc);
}

void MyRender::LoadRoadMesh(std::shared_ptr<Mesh> m, glm::vec4 color, float width, float depth)
{
	const glm::vec3 vertices[] = {
		  vec3(-width / 2, 0.0f, -depth / 2),
		  vec3(width / 2, 0.0f, -depth / 2),
		  vec3(width / 2, 0.0f, depth / 2),
		  vec3(-width / 2, 0.0f, depth / 2) };
	const glm::vec3 normal = vec3(0.0f, 1.0f, 0.0f);
	const glm::vec2 texCoords[] = {
	  vec2(0.0f, 0.0f),
	  vec2(0.0f, 1.0f),
	  vec2(1.0f, 1.0f),
	  vec2(1.0f, 0.0f)
	};
	m->setNormal(normal);
	m->addVertices(vertices, sizeof(vertices) / sizeof(vertices[0]));
	m->addTexCoord(0, texCoords, sizeof(texCoords) / sizeof(texCoords[0]));
	m->setColor(color);
	m->addDrawCommand(
		new PGUPV::DrawArrays(GL_TRIANGLE_FAN, 0, sizeof(vertices) / sizeof(vertices[0])));
}

void MyRender::LoadCube(std::shared_ptr<Mesh> m)
{
	const glm::vec3 vertices[] = {
		vec3(-1.0, -1.0, 1.0),
		vec3(-1.0, 1.0, 1.0),
		vec3(-1.0, -1.0, -1.0),
		vec3(-1.0, 1.0, -1.0),
		vec3(1.0, -1.0, 1.0),
		vec3(1.0, 1.0, 1.0),
		vec3(1.0, -1.0, -1.0),
		vec3(1.0, 1.0, -1.0)
	};

	const std::vector<GLushort> indices = {
		1, 2, 0,
		3, 6, 2,
		7, 4, 6,
		5, 0, 4,
		6, 0, 2,
		3, 5, 7,
		1, 3, 2,
		3, 7, 6,
		7, 5, 4,
		5, 1, 0,
		6, 4, 0,
		3, 1, 5,
	};

	const glm::vec2 texCoords[] = {
		vec2(0.0, 1.0),
		vec2(1.0, 0.0),
		vec2(0.0, 0.0),
		vec2(0.0, 1.0),
		vec2(1.0, 0.0),
		vec2(0.0, 0.0),
		vec2(1.0, 1.0),
		vec2(0.0, 0.0),
		vec2(1.0, 1.0),
		vec2(1.0, 0.0),
		vec2(1.0, 1.0),
		vec2(0.0, 1.0),
		vec2(1.0, 0.0),
		vec2(1.0, 1.0),
		vec2(0.0, 1.0),
		vec2(0.0, 0.0)
	};

	m->addVertices(vertices, sizeof(vertices) / sizeof(vertices[0]));
	m->addIndices(indices);
	m->addTexCoord(0, texCoords, sizeof(texCoords) / sizeof(texCoords[0]));
	m->addDrawCommand(
		new PGUPV::DrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_SHORT, NULL));
}

