#include <PGUPV.h>

using namespace PGUPV;
using glm::vec2;
using glm::vec3;
using glm::vec4;

/* 
Rellena las funciones setup y render tal y como se explica en el enunciado de la pr�ctica.
�Cuidado! NO uses las llamadas de OpenGL directamente (glGenVertexArrays, glBindBuffer, etc.).
Usa las clases Model y Mesh de PGUPV.
*/

class MyRender : public Renderer {
public:
	void setup(void);
	void render(void);
	void reshape(uint w, uint h);
private:
	Program program;
	Model model;
	std::shared_ptr<Mesh> mesh;
};

void MyRender::setup() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	program.addAttributeLocation(0, "vPosition");
	program.loadFiles("../p0/triangles");
	program.compile();

	vec3 vertices[] = {
		vec3(-0.8, 0.9, 0),
		vec3(0.9, -0.8, 0),
		vec3(0.9, 0.9, 0),
		vec3(-0.9, 0.8, 0),
		vec3(-0.9, -0.9, 0),
		vec3(0.8, -0.9, 0)
	};

	GLushort indices[] = {
		0, 1, 2,
		3, 4, 5
	};
	
	vec4 color = vec4(0, 0, 1, 1);

	mesh = std::make_shared<Mesh>();
	
	mesh->addVertices(vertices, sizeof(vertices));
	mesh->addIndices(indices, sizeof(indices));
	mesh->setColor(color);

	GLint count = 6;
	GLint first = 0;
	mesh->addDrawCommand(
		new PGUPV::DrawArrays(GL_TRIANGLES, first, count));

	model.addMesh(mesh);
}

void MyRender::render() {
	glClear(GL_COLOR_BUFFER_BIT);
	program.use();
	model.render();
}

void MyRender::reshape(uint w, uint h) {
	glViewport(0, 0, w, h);
}

int main(int argc, char *argv[]) {
	App &myApp = App::getInstance();
	myApp.initApp(argc, argv, PGUPV::DOUBLE_BUFFER);
	myApp.getWindow().setRenderer(std::make_shared<MyRender>());
	return myApp.run();
}